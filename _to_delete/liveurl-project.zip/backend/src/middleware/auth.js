import { supabaseAdmin } from '../lib/supabase.js';

/**
 * Verifies the Supabase-issued JWT sent as `Authorization: Bearer <token>`.
 * Supabase Auth issues and manages these tokens itself (login, refresh,
 * password reset, email verification) — this middleware just validates
 * the token on each request and attaches the resolved user to req.user.
 *
 * Routes that should also work for anonymous visitors (e.g. creating a
 * link without logging in, per PRD user story 1) use `optionalAuth`
 * instead of `requireAuth`.
 */
export async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Missing bearer token' });
  }

  const { data, error } = await supabaseAdmin.auth.getUser(token);
  if (error || !data?.user) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  req.user = data.user;
  next();
}

export async function optionalAuth(req, _res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    req.user = null;
    return next();
  }

  const { data } = await supabaseAdmin.auth.getUser(token);
  req.user = data?.user || null;
  next();
}
