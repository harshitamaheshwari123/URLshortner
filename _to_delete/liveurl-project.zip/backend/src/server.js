import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';

import linksRouter from './routes/links.js';
import redirectRouter from './routes/redirect.js';
import analyticsRouter from './routes/analytics.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;
const FRONTEND_ORIGIN = (process.env.FRONTEND_ORIGIN || 'http://localhost:5173').split(',');

app.use(cors({ origin: FRONTEND_ORIGIN, credentials: true }));
app.use(express.json());

// PRD 5.6: rate-limited public API. Applied to the whole /api surface;
// tune per-route if you need looser limits on reads vs writes.
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api', apiLimiter);

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

app.use('/api/links', linksRouter);
app.use('/api/analytics', analyticsRouter);

// Redirect service mounted at the root, so short links look like
// https://your-domain/abc123 rather than /r/abc123 — matches PRD's
// example format (lnk.to/my-sale). Keep this LAST so it doesn't shadow /api/*.
app.use('/', redirectRouter);

app.use((err, _req, res, _next) => {
  console.error('[unhandled]', err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`LinkSnip backend listening on port ${PORT}`);
});
