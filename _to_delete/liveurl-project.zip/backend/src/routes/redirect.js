import { Router } from 'express';
import { UAParser } from 'ua-parser-js';
import crypto from 'node:crypto';
import { supabaseAdmin } from '../lib/supabase.js';

const router = Router();

// Simple, dependency-free country lookup would normally go here via a
// geoip service (e.g. ipapi.co, MaxMind). MVP scope cut: left as a stub
// returning null so the field exists in the schema and UI without adding
// an external dependency/API key requirement to run the project locally.
async function lookupGeo(_ip) {
  return { country: null, city: null };
}

function hashIp(ip) {
  if (!ip) return null;
  return crypto.createHash('sha256').update(ip).digest('hex').slice(0, 32);
}

/**
 * GET /:shortCode — the redirect service.
 * Deliberately kept as a single fast lookup (indexed short_code column,
 * PRD's suggested Redis read-through cache is the documented next step
 * for scale — see README) followed by a synchronous click-log insert.
 * PRD's async-queue requirement for click ingestion is the other
 * documented scope cut: this MVP logs the click inline, which is simpler
 * to run but means a DB hiccup can add latency to the redirect itself.
 */
router.get('/:shortCode', async (req, res) => {
  const { shortCode } = req.params;

  const { data: link, error } = await supabaseAdmin
    .from('links')
    .select('*')
    .eq('short_code', shortCode)
    .maybeSingle();

  if (error) {
    console.error('[redirect] lookup failed:', error.message);
    return res.status(500).send('Something went wrong.');
  }

  if (!link || link.is_disabled) {
    return res.status(404).send(notFoundHtml());
  }

  if (link.expires_at && new Date(link.expires_at) < new Date()) {
    return res.status(410).send(expiredHtml());
  }

  // Fire-and-forget-ish click logging: awaited, but errors don't block the redirect.
  logClick(req, link).catch((err) => console.error('[redirect] click log failed:', err.message));

  res.redirect(302, link.destination_url);
});

async function logClick(req, link) {
  const ua = new UAParser(req.headers['user-agent'] || '').getResult();
  const deviceType = ua.device.type || 'desktop';
  const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress;
  const geo = await lookupGeo(ip);

  await Promise.all([
    supabaseAdmin.from('clicks').insert({
      link_id: link.id,
      referrer: req.headers.referer || null,
      user_agent: req.headers['user-agent'] || null,
      device_type: deviceType,
      browser: ua.browser.name || null,
      country: geo.country,
      city: geo.city,
      ip_hash: hashIp(ip),
    }),
    supabaseAdmin
      .from('links')
      .update({ click_count: (link.click_count || 0) + 1 })
      .eq('id', link.id),
  ]);
}

function notFoundHtml() {
  return `<!doctype html><html><head><title>Link not found</title></head>
  <body style="font-family:sans-serif;text-align:center;padding:4rem;">
  <h1>404</h1><p>This LinkSnip link doesn't exist or has been disabled.</p></body></html>`;
}

function expiredHtml() {
  return `<!doctype html><html><head><title>Link expired</title></head>
  <body style="font-family:sans-serif;text-align:center;padding:4rem;">
  <h1>Link expired</h1><p>This link is no longer active.</p></body></html>`;
}

export default router;
