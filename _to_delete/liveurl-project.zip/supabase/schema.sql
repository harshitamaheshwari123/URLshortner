-- LinkSnip: Supabase Postgres schema
-- Run this in the Supabase SQL editor (Project > SQL Editor > New query) after creating your project.
-- Assumes Supabase Auth is enabled (auth.users table exists by default).

-- ============================================================
-- TABLE: links
-- ============================================================
create table if not exists public.links (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade,   -- null = anonymous link
  short_code text unique not null,
  destination_url text not null,
  is_custom_alias boolean not null default false,
  tags text[] default '{}',
  expires_at timestamptz,          -- null = never expires
  is_archived boolean not null default false,
  is_disabled boolean not null default false,
  click_count integer not null default 0,   -- denormalized counter, updated on each click
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_links_owner_id on public.links(owner_id);
create index if not exists idx_links_short_code on public.links(short_code);

-- ============================================================
-- TABLE: clicks (click event log — MVP writes directly here,
-- synchronously, from the redirect service. See README for the
-- documented scaling gap: production would put this behind a
-- queue + dedicated time-series store instead.)
-- ============================================================
create table if not exists public.clicks (
  id bigint generated always as identity primary key,
  link_id uuid not null references public.links(id) on delete cascade,
  clicked_at timestamptz not null default now(),
  referrer text,
  user_agent text,
  device_type text,        -- 'mobile' | 'desktop' | 'tablet' | 'unknown'
  browser text,
  country text,             -- derived from IP via geoip lookup
  city text,
  ip_hash text              -- store a hash of the IP, not the raw IP, for basic privacy hygiene
);

create index if not exists idx_clicks_link_id on public.clicks(link_id);
create index if not exists idx_clicks_clicked_at on public.clicks(clicked_at);

-- ============================================================
-- FUNCTION + TRIGGER: keep updated_at fresh
-- ============================================================
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_links_updated_at on public.links;
create trigger trg_links_updated_at
  before update on public.links
  for each row execute function public.set_updated_at();

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.links enable row level security;
alter table public.clicks enable row level security;

-- Owners can do anything with their own links.
drop policy if exists "links_owner_full_access" on public.links;
create policy "links_owner_full_access"
  on public.links
  for all
  using (auth.uid() = owner_id)
  with check (auth.uid() = owner_id);

-- Anyone (including anon) can read a non-archived, non-disabled link by short_code —
-- required so the redirect service (using the anon/service key) can resolve links.
-- In practice the backend uses the service_role key for redirects/writes, which
-- bypasses RLS entirely; this policy exists so the same table is safe if you ever
-- query it directly from the frontend with the anon key.
drop policy if exists "links_public_read" on public.links;
create policy "links_public_read"
  on public.links
  for select
  using (is_archived = false and is_disabled = false);

-- Clicks: only the link owner can read click data for their links.
-- Inserts happen server-side with the service_role key (bypasses RLS).
drop policy if exists "clicks_owner_read" on public.clicks;
create policy "clicks_owner_read"
  on public.clicks
  for select
  using (
    exists (
      select 1 from public.links
      where public.links.id = clicks.link_id
      and public.links.owner_id = auth.uid()
    )
  );
